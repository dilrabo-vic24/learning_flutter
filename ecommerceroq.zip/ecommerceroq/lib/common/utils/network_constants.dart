class NetworkConstants {
  static const productsUrl = "https://api.escuelajs.co/api/v1/products";
  static const categoriesUrl = "https://api.escuelajs.co/api/v1/categories";
}
