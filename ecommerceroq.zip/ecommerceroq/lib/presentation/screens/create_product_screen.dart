import 'dart:developer';

import 'package:ecommerce_app_2/data/models/product_model.dart';
import 'package:ecommerce_app_2/data/services/injection_container.dart';
import 'package:ecommerce_app_2/presentation/screens/products_screen.dart';
import 'package:ecommerce_app_2/providers/product_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CreateProductScreen extends StatefulWidget {
  const CreateProductScreen({super.key});

  @override
  State<CreateProductScreen> createState() => _CreateProductScreenState();
}

class _CreateProductScreenState extends State<CreateProductScreen> {
  final TextEditingController title = TextEditingController();
  final TextEditingController price = TextEditingController();
  final TextEditingController description = TextEditingController();

  final prodProvider = getIt<ProductProvider>();

  @override
  void initState() {
    super.initState();
    prodProvider.getCategories();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<ProductProvider>(
        builder: (context, value, child) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Add New Product",
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 30)),
                SizedBox(height: 45),
                TextField(
                  decoration: InputDecoration(
                      hintText: "Title", border: OutlineInputBorder()),
                  controller: title,
                ),
                SizedBox(height: 10),
                TextField(
                  decoration: InputDecoration(
                      hintText: "Price", border: OutlineInputBorder()),
                  controller: price,
                ),
                SizedBox(height: 10),

                TextField(
                  decoration: InputDecoration(
                      hintText: "Description", border: OutlineInputBorder()),
                  controller: description,
                ),
                SizedBox(height: 20),
                SizedBox(
                  height: 100,
                  child: value.categories.isEmpty
                      ? ElevatedButton(
                          onPressed: () async {
                            await value.getCategories();
                            log(value.selectedCategory.toString());
                          },
                          child: Text("Select category"),
                        )
                      : ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: value.categories.length,
                          itemBuilder: (context, index) {
                            final Category category = value.categories[index];
                            return GestureDetector(
                              onTap: () {
                                value.selectedCategory = category.id!;
                                value.updateSelectedCat(category.id!);
                              },
                              child: Container(
                                alignment: Alignment.center,
                                margin: EdgeInsets.only(right: 10),
                                height: 50,
                                decoration: BoxDecoration(
                                    color: Colors.amber,
                                    border: value.categories[index].id ==
                                            value.selectedCategory
                                        ? Border.all(
                                            color: Colors.black,
                                            width: 2,
                                          )
                                        : null),
                                child: Text(
                                  category.name.toString(),
                                  style: TextStyle(
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
                // ListWheelScrollView(
                //   itemExtent: 2,
                //   children: List.generate(
                //     prodProvider.categories.length,
                //     (index) {
                //       return Text(prodProvider.categories[index].name.toString());
                //     },
                //   ),
                // ),
                SizedBox(height: 50),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      backgroundColor: Colors.green,
                      fixedSize: Size(320, 40)),
                  onPressed: () async {
                    final res = await prodProvider.addNewProduct(
                      title: title.text.trim(),
                      description: description.text.trim(),
                      price: double.parse(
                        price.text.trim(),
                      ),
                    );
                    Navigator.pop(context);
                  },
                  child: prodProvider.isLoading
                      ? Center(
                          child: CircularProgressIndicator(),
                        )
                      : Text(
                          "Add product",
                          style: TextStyle(color: Colors.white, fontSize: 25),
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
