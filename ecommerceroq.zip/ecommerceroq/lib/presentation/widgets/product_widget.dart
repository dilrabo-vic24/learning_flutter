import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // Provider im
import 'package:ecommerce_app_2/providers/product_provider.dart';

class ProductCard extends StatelessWidget {
  final String title;
  final String image;
  final int price;
  final int id;

  const ProductCard({
    required this.title,
    required this.image,
    required this.price,
    super.key,
    required this.id,
  });

  @override
  Widget build(BuildContext context) {
    final productProvider =
        Provider.of<ProductProvider>(context, listen: false);

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Center(
                child: Image.network(
                  image,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              "USD $price",
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                TextButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: Text(
                            title,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 3,
                          ),
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 230,
                                height: 200,
                                child: Image.network(image),
                              ),
                              const SizedBox(height: 10),
                              Text("Price: USD $price"),
                              const SizedBox(height: 10),
                            ],
                          ),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: const Text("Close"),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: const Text("View"),
                ),
                TextButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Row(
                          children: [
                            Text("Product added to cart!"),
                            SizedBox(width: 10),
                            Icon(
                              Icons.check,
                              color: Colors.white,
                            )
                          ],
                        ),
                        backgroundColor: Colors.green,
                      ),
                    );
                  },
                  child: const Text("Buy"),
                ),
                TextButton(
                  onPressed: () async {
                    final isDeleted =
                        await productProvider.deleteProduct(productId: id);
                    if (isDeleted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Product deleted successfully!"),
                        ),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Failed to delete the product."),
                        ),
                      );
                    }
                  },
                  child: const Text("Delete"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
