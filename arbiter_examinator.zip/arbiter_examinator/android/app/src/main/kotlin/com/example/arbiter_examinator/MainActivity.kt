package com.example.arbiter_examinator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
