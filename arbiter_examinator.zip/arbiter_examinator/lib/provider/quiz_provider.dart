import 'dart:async';
import 'dart:developer';

import 'package:arbiter_examinator/data/models/quiz_submission/quiz_result.dart';
import 'package:arbiter_examinator/data/models/quiz_submission/submit_quiz_data.dart';
import 'package:arbiter_examinator/data/repositories/quiz_repo.dart';
import 'package:arbiter_examinator/data/models/quiz/quiz_data.dart';
import 'package:flutter/material.dart';

class QuizProvider extends ChangeNotifier {
  final QuizRepo quizRepo;

  QuizProvider(this.quizRepo);

  bool isLoading = false;
  String message = '';
  QuizResponse? quiz;
  QuizResult? quizResult;

  int _remainingTime = 0;
  Timer? _timer;

  int get remainingTime => _remainingTime;

  Future<void> getQuiz(String examId, {required int examDuration}) async {
    isLoading = true;
    notifyListeners();
    
    log("data in usecase: ");
    final result = await quizRepo.getQuiz(examId: examId);
    isLoading = false;
    
    result?.fold(
      (error) => message = error,
      (_) {
        quiz = QuizResponse(data: _!.data.take(8).toList());
        _remainingTime = examDuration;
        startTimer();
      },
    );
    
    notifyListeners();
  }

  void startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_remainingTime > 0) {
        _remainingTime--;
        notifyListeners();
      } else {
        _timer?.cancel();
        submitQuiz(examId: '', data: []); // Vaqt tugaganda avtomatik submit
      }
    });
  }

  Future<void> submitQuiz({
    required String examId,
    required List<SubmitQuizData> data,
  }) async {
    isLoading = true;
    notifyListeners();
    
    log(data.toString());
    final result = await quizRepo.submitQiuz(examId: examId, data: data);
    log(result.toString());

    isLoading = false;
    _timer?.cancel(); // Submit bo'lgandan keyin taymer to‘xtaydi

    result?.fold(
      (error) => message = error,
      (_) => quizResult = _,
    );
    
    notifyListeners();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
