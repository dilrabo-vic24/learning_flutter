class PrefsKeys {
  static String tokenKey = "token";
}