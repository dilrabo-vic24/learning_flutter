class AppImages {
  static const String baseImageUrl = "assets/images";

  static const String profileImage = "$baseImageUrl/profile.png";
}