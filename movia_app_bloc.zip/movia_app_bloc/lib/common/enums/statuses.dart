enum Statuses { Initial, Loading, Succes, Error }
