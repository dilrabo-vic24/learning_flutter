package com.example.solid_lesson_todo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
